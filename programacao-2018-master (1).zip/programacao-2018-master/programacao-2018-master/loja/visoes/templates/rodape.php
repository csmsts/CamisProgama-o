<footer>

    <p>endereço</p>
    <p>telefone</p>
</footer>
</body>
</html>