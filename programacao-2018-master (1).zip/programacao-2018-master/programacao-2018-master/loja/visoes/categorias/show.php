<html>
    <head>

    </head>


    <body>

        <h1>Detalhes da categoria <?= $categoria->getNome()?></h1>
        <p><?= $categoria->$getDescricao() ?></p>
    </body>



</html>